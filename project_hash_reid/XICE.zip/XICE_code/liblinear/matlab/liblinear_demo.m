
% addpath /home/dongcheng/liblinear-1.94/matlab;
% Ytr=double(Ytr);Yte=double(Yte);
% option = ['-s 2  -q '];
% tic;
% model_linear = train( Ytr, ftrain,option);
% [predict_label_L, accuracy_L, dec_values_L] =...
%     predict(Yte, feature ,model_linear);
% toc;

%load /home/dongcheng/dataset/multi_pie_all.mat;
%load /home/dongcheng/dataset/multi_pie_15tr15te.mat;
%load /home/dongcheng/dataset/multi_pie_15tr15te_rfd.mat;
%load /home/dongcheng/dataset/caltech101_15tr15te1_rfd.mat;
%load /home/dongcheng/dataset/multi_pie/multi_pie_5tr25te_rfd.mat;
%load /home/dongcheng/dataset/53obj/53objects_2tr3te.mat; 
load /home/dongcheng/dataset/53obj/53objects_2tr3te_rfd_h4.mat; 
addpath /home/dongcheng/liblinear-1.94/matlab;
Ytr=double(Ytr);Yte=double(Yte);
Xtr=sparse(double(Xtr));Xte=sparse(double(Xte));
option = ['-s 2  -q '];
tic;
model_linear = train( Ytr, Xtr,option);
[predict_label_L, accuracy_L, dec_values_L] =...
    predict(Yte, Xte ,model_linear);
toc;