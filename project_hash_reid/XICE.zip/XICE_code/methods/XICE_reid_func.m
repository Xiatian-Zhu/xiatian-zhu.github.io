function [view1_code, view2_code]= XICE_reid_func( data, opts )

opts.run_times = 1;

opts.loss = 'Hinge';
opts.out_iter = 20;  % 20 iterations is enough
opts.in_iter = 10;
opts.pos_ratio = 1;
opts.neg_ratio = 0;
opts.para.gamma = 0.01;
%%%%%%%%%%%%%%%%%%
% default parameter
opts.para.alpha = 20;  % alpha is divided by 10 in paper
opts.para.regu = 0.05;
opts.lambda = 10;
opts.nu = 1e-2;
%%%%%%%%%%%%%%%%%%
if isfield(opts, 'para1')
    opts.para.alpha = opts.para1;
    opts.para.beta  = opts.para1;
    fprintf(opts.fid, 'alpha: %.2f\r\n',opts.para.alpha);
end
if isfield(opts,'para2')
    opts.para.regu = opts.para2;
    fprintf(opts.fid, 'regu: %.2f\r\n',opts.para.regu);
end
if isfield(opts,'para3')
    opts.nu = opts.para3;
    fprintf(opts.fid, 'nu: %.2f\r\n',opts.nu);
end

if isfield(opts,'para4')
    opts.lb = opts.para4;
    fprintf(opts.fid, 'lambdaB: %.2f\r\n',opts.lb);
end
opts.para.beta = opts.para.alpha;

[Wx, Wy, out] = XICE_train_reid(data, opts);



% tic;
view1_code = ( data.probe_test * Wx >0);
view2_code = ( data.gallery_test * Wy>0 );

view1_code = bitCompact(view1_code);
view2_code = bitCompact(view2_code);
aa = 1;

end