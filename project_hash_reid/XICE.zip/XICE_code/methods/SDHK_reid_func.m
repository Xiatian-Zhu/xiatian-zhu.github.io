function [view1_code, view2_code] = SDHK_reid_func(data, opts)



traindata = [data.probe_train; data.gallery_train] ;
testdata = [data.probe_test; data.gallery_test];

    traingnd = [data.train_label; data.train_label];


Ntrain = size(traindata,1);
% Use all the training data
X = traindata;
label = double(traingnd);
label = changeY(label);

% % get anchors
n_anchors = 1000;
% rand('seed',1);
anchor = X(randsample(Ntrain, n_anchors),:);
Dis = sqdist2(X,anchor);
Dis = Dis.^2;
sigma = mean(min(Dis,[],2).^0.5);
% determin rbf width sigma

% sigma = 0.4; % for normalized data
PhiX = exp(-sqdist2(X,anchor)/(2*sigma*sigma));
%PhiX = [PhiX, ones(Ntrain,1)];
Phi_traindata = PhiX;

Phi_testdata1 = exp(-sqdist2(data.probe_test,anchor)/(2*sigma*sigma));
Phi_testdata2 = exp(-sqdist2(data.gallery_test,anchor)/(2*sigma*sigma));
Phi_testdata = [Phi_testdata1;Phi_testdata2];
% Phi_traindata = X;
% Phi_testdata = testdata;
% PhiX = X;
% learn G and F
maxItr = 5;
gmap.lambda = 1; gmap.loss = 'Hinge';
Fmap.type = 'RBF';
Fmap.nu = 1e-5; %  penalty parm for F term
Fmap.lambda = 1e-2;

%% run algo
nbits = opts.bit;

% Init Z
randn('seed',3);
Zinit=sign(randn(Ntrain,nbits));


debug = 0;
[~, F, H] = SDH(PhiX,label,Zinit,gmap,Fmap,[],maxItr,debug);

%% evaluation


H = Phi_traindata*F.W > 0;
tH = Phi_testdata*F.W > 0;


B = compactbit(H);
tB = compactbit(tH);

n1 = size(data.probe_test,1);
view1_code = tB(1:n1,:);
view2_code = tB(n1+1:end,:);

end

function Y1 = changeY(Y)
id = unique(Y);
%Y1 = zeros(length(Y));
for i = 1:length(Y)
    Y1(i) = find(id == Y(i));
end
Y1 = Y1(:);
end


