function [view1_code, view2_code ] = CCAITQ_reid_func(data,opts)

nbits = opts.bit;


Xtr = [data.probe_train; data.gallery_train];
Ytr = [data.train_label; data.train_label];
y = changeY(Ytr);
Y = sparse(1:length(y), double(y), 1); Y = full(Y);


num_training=size(Xtr,1);

% generate training ans test split and the data matrix
XX = Xtr;
% center the data, VERY IMPORTANT
sampleMean = mean(XX,1);
XX = (XX - repmat(sampleMean,size(XX,1),1));

% PCA
%[pc, l] = eigs(cov(XX(1:num_training,:)),nbits);
% CCA
reg = 0.0001 ;
[Wx, r] = cca(XX, Y, reg);
pc = Wx(:,1:nbits)*diag(r(1:nbits)); 
XX = XX * pc;
% ITQ
[Y, R] = ITQ(XX(1:num_training,:),50);

Y1 = data.probe_test*pc;
Y2 = data.gallery_test*pc;
Y1 = Y1*(R)>0;
Y2 = Y2*(R)>0;

view1_code = bitCompact(Y1);
view2_code = bitCompact(Y2);

end

function [B,R] = ITQ(V, n_iter)
%
% main function for ITQ which finds a rotation of the PCA embedded data
% Input:
%       V: n*c PCA embedded data, n is the number of images and c is the
%       code length
%       n_iter: max number of iterations, 50 is usually enough
% Output:
%       B: n*c binary matrix
%       R: the c*c rotation matrix found by ITQ
% Author:
%       Yunchao Gong (yunchao@cs.unc.edu)
% Publications:
%       Yunchao Gong and Svetlana Lazebnik. Iterative Quantization: A
%       Procrustes Approach to Learning Binary Codes. In CVPR 2011.
%

% initialize with a orthogonal random rotation
bit = size(V,2);
R = randn(bit,bit);
[U11 S2 V2] = svd(R);
R = U11(:,1:bit);

% ITQ to find optimal rotation
for iter=0:n_iter
    Z = V * R;      
    UX = ones(size(Z,1),size(Z,2)).*-1;
    UX(Z>=0) = 1;
    C = UX' * V;
    [UB,sigma,UA] = svd(C);    
    R = UA * UB';
end

% make B binary
B = UX;
B(B<0) = 0;
end

function Y1 = changeY(Y)
id = unique(Y);
%Y1 = zeros(length(Y));
for i = 1:length(Y)
    Y1(i) = find(id == Y(i));
end
Y1 = Y1(:);
end