%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% KSH main program of CVPR'12 "Supervised Hashing with Kernels"
% Written by Wei Liu (wliu@ee.columbia.edu) 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function  [view1_code, view2_code] = KSH_reid_func(data,opts)
%load demo_patch_data;

traindata = [data.probe_train; data.gallery_train];
traingnd = [data.train_label; data.train_label ];

[n,d] = size(traindata);

m = 500;    % number of anchors
fprintf('anchor :%d \n', m);
r = opts.bit;     % number of hash bits
trn = size(traindata,1);% 1500; % number of labeled training samples
%load label_index_2k; % indexes of labeled samples
%load sample_300;     % indexes of anchors

tmp = randperm(n);
sample = tmp(1:m); % anchor idx

%% Kernel-Based Supervised Hashing (KSH)
% kernel computing 

anchor = traindata(sample',:);
KTrain = sqdist1(traindata',anchor');
sigma = mean(mean(KTrain,2));
KTrain = exp(-KTrain/(2*sigma));
mvec = mean(KTrain);
KTrain = KTrain-repmat(mvec,n,1);

% pairwise label matrix
tmp = randperm(n);
label_index = tmp(1:trn);

trngnd = traingnd(label_index');
temp = repmat(trngnd,1,trn)-repmat(trngnd',trn,1);
S0 = -ones(trn,trn);
tep = find(temp == 0);
S0(tep) = 1;
clear temp;
clear tep;
S = r*S0;

% projection optimizationvc
KK = KTrain(label_index',:);
RM = KK'*KK; 
A1 = zeros(m,r);
flag = zeros(1,r);
t1 = tic;
for rr = 1:r
    if mod(rr,8)==0
        fprintf('bit: %d  %.2f\n',rr,toc(t1));
        
    end
    if rr > 1
        S = S-y*y';
    end
    
    LM = KK'*S*KK;
    [U,V] = eig(LM,RM);
    eigenvalue = diag(V)';
    [eigenvalue,order] = sort(eigenvalue,'descend');
    A1(:,rr) = U(:,order(1));
    tep = A1(:,rr)'*RM*A1(:,rr);
    A1(:,rr) = sqrt(trn/tep)*A1(:,rr);
    clear U;    
    clear V;
    clear eigenvalue; 
    clear order; 
    clear tep;  
    
    [get_vec, cost] = OptProjectionFast(KK, S, A1(:,rr), 500);
    y = double(KK*A1(:,rr)>0);
    ind = find(y <= 0);
    y(ind) = -1;
    clear ind;
    y1 = double(KK*get_vec>0);
    ind = find(y1 <= 0);
    y1(ind) = -1;
    clear ind;
    if y1'*S*y1 > y'*S*y
        flag(rr) = 1;
        A1(:,rr) = get_vec;
        y = y1;
    end
end

% encoding
% train_time = toc;
% fprintf(opts.fid,'train_time: %.2f\n',train_time); 

% load ksh_12;
%% test
% encoding
tic;
testdata = data.probe_test;
tn = size(testdata,1);
KTest1 = sqdist1(testdata',anchor');
KTest1 = exp(-KTest1/(2*sigma));
KTest1 = KTest1-repmat(mvec,tn,1);
tY1 = single(A1'*KTest1' > 0);
view1_code = bitCompact(tY1');

testdata = data.gallery_test;
tn = size(testdata,1);
KTest2 = sqdist1(testdata',anchor');
KTest2 = exp(-KTest2/(2*sigma));
KTest2 = KTest2-repmat(mvec,tn,1);
tY2 = single(A1'*KTest2' > 0);
view2_code = bitCompact(tY2');


end