function train_dmb(da, ml, bit, dataset, method, setting)


addpath(genpath('./methods/'));
addpath(genpath('./XICE/'));
addpath(genpath('./util/'));
addpath(genpath('./liblinear/matlab/'));

dbstop if error
% training
for b = bit
    for i = da
        for j = ml
            
            opts.data = dataset{i};
            opts.bit = b;
            opts.method = method{ j };            
            opts = set_opt(opts, setting);
            
            if setting.train ~= 0
                func_train_code(opts);
            end
            
        end
    end
end

% testing
for b = bit
    for i = da
        for j = ml
            
            opts.data = dataset{i};
            opts.bit = b;
            opts.method = method{ j };            
            opts = set_opt(opts, setting);                        
            func_test_hash_map(opts);                        
            
        end
    end
end

end% end func run_dmb

