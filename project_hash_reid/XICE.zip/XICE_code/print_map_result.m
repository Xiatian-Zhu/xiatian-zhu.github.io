function print_map_result(opts, mean_ap, mean_r1)

fid1 = opts.fid;
fid2 = opts.all_result_fid;

fprintf(fid1,' method: %s, ',opts.method);
fprintf(fid1,' bit: %.3f, ', opts.bit );
fprintf(fid1, 'map :%.5f, rank1:%.5f \n', mean_ap, mean_r1);

fprintf(fid2,' method: %s, ',opts.method);
fprintf(fid2,' bit: %.3f, ', opts.bit );
fprintf(fid2, 'map :%.5f, rank1:%.5f \n', mean_ap, mean_r1);

fprintf(' method: %s, bit: %.3f, ',opts.method, opts.bit);
fprintf('map :%.5f, rank1:%.5f \n', mean_ap, mean_r1);


end