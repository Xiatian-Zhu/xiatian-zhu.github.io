function func_train_code(opts)

    
for split_idx = 1:opts.split_num
 
    fprintf('training split %d\n',split_idx);
    data = load_data(opts, split_idx);
    
    eval(['F = @',opts.method,'_reid_func;']);
    s2 = tic;        
    
    [view1_code, view2_code]= feval(F,data,opts);
    
    train_time = toc(s2);
    
    hashcode_matfile = sprintf('%s_%s_bit%d_split%d',opts.data,opts.method,opts.bit,split_idx);
    hashcode_path = sprintf('%s_%s_bit%d/',opts.data,opts.method,opts.bit);    
    tmppath = [opts.record_path,'hashcode/',hashcode_path];
    if ~exist(tmppath, 'dir')
        mkdir(tmppath);
    end        
    
    save([tmppath, hashcode_matfile], 'view1_code','view2_code');            
    fprintf(' %s   %.2f s\n',opts.method, train_time);
            
end  % split


fprintf(opts.fid,' %s  ',opts.method);
fprintf(opts.fid,'train_time: %.2f s\r\n',train_time);
end



