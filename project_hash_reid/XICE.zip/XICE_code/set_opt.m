function opts = set_opt(opts, setting)
opts.Ntarget = 10;
opts.split_num = 1;
opts.part_num = 10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isfield(setting, 'split_num')
    opts.split_num = setting.split_num;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% set record path %%%
tmppath = sprintf( './record_%s/', opts.data);
if ~exist(tmppath, 'dir')
    mkdir(tmppath);
    mkdir([tmppath,'hashcode/']);
end
opts.record_path = tmppath;

%%%% set all test result fid %%%
tmpname = sprintf('all_result_%s.csv', opts.data);
opts.all_result_fid = fopen([tmppath, tmpname], 'a+');

%%%% set singe method test result fid %%%
tmpname = sprintf('%s_%s.txt', opts.data, opts.method);
opts.fid = fopen([tmppath, tmpname], 'a+');

%%%% set singe method test result fid %%%
%opts.data_path = sprintf('./data_%s/', opts.data);
opts.data_path = sprintf('./data/');

%%% set XICE parameter %%%
opts.lambda = 1e-2;
opts.nu = 1e-2;
if isfield(setting, 'para1')
    opts.para1 = setting.para1;
end
if isfield(setting, 'para2')
    opts.para2 = setting.para2;
end
if isfield(setting, 'para3')
    opts.para3 = setting.para3;
end
if isfield(setting, 'para4')
    opts.para4 = setting.para4;
end

end