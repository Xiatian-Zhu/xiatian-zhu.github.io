dataset{1} = 'cuhk03';
dataset{2} = 'sysu';

method{1} = 'XICE'; method{2} = 'CCAITQ';
method{3} = 'KSH';method{4} = 'SDHK';

bit = [ 32 ];
ml = [1];
da = [1];


setting.train = 1;
setting.map = 1;
train_dmb(da, ml, bit, dataset, method, setting);