function func_test_hash_map(opts)

split_num = opts.split_num;
all_map = zeros(split_num,1);
all_r1 = zeros(split_num,1);


for split_idx = 1:split_num

    %%% load test id %%%
    data = load_data(opts, split_idx);
    

        %%% load test feat %%%
        hashcode_matfile = sprintf('%s_%s_bit%d_split%d',opts.data,opts.method,opts.bit,split_idx);
        
        hashcode_path = sprintf('%s_%s_bit%d/',opts.data,opts.method,opts.bit);
        tmppath = [opts.record_path,'hashcode/',hashcode_path];
        
        load([tmppath, hashcode_matfile], 'view1_code','view2_code');
        
        %%% calculate dist matrix %%%
        dist = HammingDist(view2_code,view1_code);
    
    dist = double(dist);
    
    %%% start compute map %%%
    galleryID = data.groupTest2;
    probe_label = data.groupTest1;
    
    [ap r1 CMC]=evaluation_mAP(dist,galleryID,probe_label);
    
    all_map(split_idx) = mean(ap);
    all_r1(split_idx) = r1;
    
    
end  % split
%%%%%%%%%%%%%save result%%%%%%%%%%%%%%
mean_ap = mean(all_map);
mean_r1 = mean(all_r1);

print_map_result(opts, mean_ap, mean_r1);

end

