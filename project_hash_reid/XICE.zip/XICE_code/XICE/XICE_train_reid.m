function [Wx, Wy, out] = XICE_train_reid(data, opts)

% Author:
%    Botong Wu, Dongcheng Huang
% Publications:
%    Xiatian Zhu, Botong Wu, Dongcheng Huang, Wei-Shi Zheng 
%    "Fast Open-World Person Re-Identification"
%    2017 IEEE TRANSACTIONS ON IMAGE PROCESSING
%

% train hash code for reid

X1 = data.probe_train;
X2 = data.gallery_train;
[n, dx] = size(X1);
dy = size(X2, 2);
X = blkdiag(X1 , X2);
XX = X' * X;

%--------------------------
S = data.S;

pairNum = length(find(S(:)==1));
SS =   [ - diag(sum(S, 1)),   S' ;  S,  - diag(sum(S, 2)) ];
cov_Xtr = (opts.para.alpha) * 2*n / pairNum *  X' * SS * X;
tmp = size(cov_Xtr,1)/2;

% View Context Discrepancy Regularisation.
cov_regu = opts.para.regu*2*n*[-eye(tmp),eye(tmp); eye(tmp),-eye(tmp)];
cov_Xtr = cov_Xtr + cov_regu;

W1 = myPCA(X1,opts.bit);
W2 = myPCA(X2,opts.bit);
W = [W1;W2];
% Results are not sensitive to the initialization step of W
% W = rand(size(W));
% W = myPCA_min(cov_Xtr,opts.bit);

%opts.out_iter = 50
setting.record = 0; %
setting.mxitr  = opts.in_iter;
setting.xtol = 1e-5;
setting.gtol = 1e-5;
setting.ftol = 1e-8;
out_y = zeros(6, opts.out_iter + 1);

%initialization
B = sign(X * W);
[W, ~] = OptStiefelGBB(W, @IOH_obj, setting,       X, cov_Xtr, XX, B, 1);
B = sign(X * W);
y = changeY(data.train_label); newY = [y;y];
Y =  sparse(1:length(y), double(y), 1); Y = full(Y);
newBigY = [Y;Y];

%addpath('your liblinear path')

%%%%%%%%%%%%%%%%%%%%%%%%
for iter = 0:opts.out_iter        
    switch opts.loss
        case 'L2'
            [Wg, ~, ~] = RRC(B, newY, opts.lambda);
            %[Wg1, ~, ~] = RRC(B1, y, opts.lambda);
            %[Wg2, ~, ~] = RRC(B2, y, opts.lambda);
        case 'Hinge'
            svm_option = ['-q -s 4 -c ', num2str(1/opts.lambda)];
            
            model = train(double(newY),sparse(B),svm_option);
            Wg = model.w';
    end
    %G.W1 = Wg1;G.W2 = Wg2;
    G.w = Wg;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    graph_loss = -trace(W' * cov_Xtr * W );
    switch opts.loss
        case 'L2'
            reg_loss1 = norm(Y - B(1:n,:)*Wg, 'fro')^2;
            reg_loss2 = norm(Y - B(n+1:end,:)*Wg, 'fro')^2;
            reg_loss = reg_loss1 + reg_loss2;
        case 'Hinge'
            tmp = B*Wg;
            posPart = tmp;
            posPart(newBigY==0) = 0;
            repmatPos = posPart;
            for iii = 1:size(tmp,1)
                this_row = posPart(iii,:);
                val = sum(this_row);
                repmatPos(iii,:) = val;
            end
            res = repmatPos - tmp + newBigY - 1; % > 1 is good, no loss
            res2 = res(:);
            res2(res2 > 0) = [];
            reg_loss = -sum(res2);
    end
    
    quantization_loss = norm(B - X * W, 'fro')^2;
    whole_obj = graph_loss + opts.nu*(reg_loss) + quantization_loss;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % B step
    nu = opts.nu;
    W1 = W(1:dx, :);    W2 = W(dx+1:end, :);
    B1 = B_step(X1, W1, Wg, y, nu, opts);
    B2 = B_step(X2, W2, Wg, y, nu, opts);
    B = [B1; B2];
    %B = sign(X * W);            
    
    % W step
    [W, ~] = OptStiefelGBB(W, @IOH_obj, setting, X, cov_Xtr, XX, B, 1);           
        
    out_y(1, iter+1) =  graph_loss;
    out_y(2, iter+1) =  reg_loss;
    out_y(3, iter+1) =  quantization_loss;
    
    aaa = 1;
    %mean(mean(cov_Xtr.^2))
end
Wx = W(1:dx, :);
Wy = W(dx+1:end, :);
out_x = 0:opts.out_iter;
out = [out_x', out_y'];
end

function [W] = myPCA(X, redim)
% X is n * d matrix
COV_Matrix = X' * X;
[EigenVecC,EigenDiag] = eig(COV_Matrix);
EigenDiag = diag(EigenDiag)';
[EigenDiagSorted,Index] = sort(-EigenDiag);
EigenDiag = -1 * EigenDiagSorted;
EigenVecC = EigenVecC(:,Index);
W = EigenVecC(:,1 : redim);
end



function Y1 = changeY(Y)
id = unique(Y);
%Y1 = zeros(length(Y));
for i = 1:length(Y)
    Y1(i) = find(id == Y(i));
end
Y1 = Y1(:);
end

function B = B_step(X, WF, Wg, y, nu, opts)

% Author:
%    Fumin Shen
% Publications:
%    Fumin Shen, Chunhua Shen, Wei Liu, Heng Tao Shen,  "Supervised Discrete Hashing",
%    IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2015.
% Source:
%    https://github.com/bd622/DiscretHashing

Y = sparse(1:length(y), double(y), 1); Y = full(Y);
XF = X*WF;
Q = nu*XF + Y*Wg';
switch opts.loss
    case 'L2'
        B = zeros(size(XF));
        for time = 1:3
            Z0 = B;
            for k = 1 : size(B,2)
                Zk = B; Zk(:,k) = [];
                Wkk = Wg(k,:); Wk = Wg; Wk(k,:) = [];
                B(:,k) = sign(Q(:,k) -  Zk*Wk*Wkk');
            end
            
            if norm(B-Z0,'fro') < 1e-6 * norm(Z0,'fro')
                break
            end
        end
    case 'Hinge'
        %delta = 1/nu;
        if isfield(opts,'lb')
            delta = opts.lb;
        else
            delta = 1/nu;
        end
        B = zeros(size(XF));
        for ix_z = 1 : size(XF,1)
            w_ix_z = bsxfun(@minus, Wg(:,y(ix_z)), Wg);
            B(ix_z,:) = sign(2*nu*XF(ix_z,:) + delta*sum(w_ix_z,2)');
        end
end
end