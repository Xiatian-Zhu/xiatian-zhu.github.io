function [F,G,out1, out2] = IOH_obj(W, X, cov_Xtr,XX, B, alpha, dx, dy)
% IOH_OBJ is the objective function when fix B
%
% Publications:
%    Botong Wu, Qiang Yang, Wei-Shi Zheng, Yizhou Wang, Jingdong Wang
%    "Quantized Correlation Hashing for Fast Cross-Modal Search"
%    2015 24th International Joint Conference on Artificial Intelligence

n = size(X, 1);
F = alpha * norm(B - X * W, 'fro')^2 - ...
    trace(W' * cov_Xtr * W);
out1 = alpha * norm(B(1:n/2, :) - X(1:n/2, :) * W, 'fro')^2;

out2 = alpha * norm(B(n/2+1:end, :) - X(n/2 +1:end, :) * W, 'fro')^2;
G = 2 * alpha * XX * W - 2 * cov_Xtr * W - ...
    2 * alpha * X' * B;

end

