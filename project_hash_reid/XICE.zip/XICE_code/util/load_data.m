function data = load_data(opts, split_idx)

opts.dataset = sprintf('%s_%d_open_set.mat',opts.data,split_idx);
filename = [opts.data_path, opts.dataset];

load (filename);

data.probe_train =  Center_Data( data.probe_train);
data.gallery_train = Center_Data( data.gallery_train);
data.probe_test =  Center_Data( data.probe_test);
data.gallery_test =  Center_Data( data.gallery_test);

end

