% normalize data
%  X   n * m      n is the number of data    m is the size of dimension

function X = Center_Data( X )

% normalize data
% 
norm_x = sqrt(sum(X .^ 2,2));
X = X./repmat(norm_x,1,size(X,2));

% mean-center data
mean_x = mean(X,1);
X = X - repmat( mean_x,size( X, 1),1 );

norm_x = sqrt(sum(X .^ 2,2));
X = X./repmat(norm_x,1,size(X,2));



