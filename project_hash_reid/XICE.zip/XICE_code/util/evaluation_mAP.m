function [ap r1 CMC ]=evaluation_mAP(dist,galleryID,probeID)

%%% dist  N gllaery(Test)  * N probe(Query)
% % nQuery = 1000;
% % nTest  = size(data.txt_test,1);
% % 
% % gallery_feature = data.txt_test;
% % probe_feature = data.img_test(1:nQuery,:);
% % 
% % dist = pdist2(gallery_feature, probe_feature );
% % 
% % testID = data.groupTest2;
% % queryID = data.groupTest1(1:nQuery);

[nTest, nQuery] = size(dist);

ap = zeros(nQuery, 1); % average precision
CMC = zeros(nQuery, nTest);

testID = galleryID;
queryID = probeID;
count_r1 = 0;
tic;
for k = 1:nQuery
    
    good_index = find(testID == queryID(k));
    score = dist(:, k);
    [~, index] = sort(score, 'ascend');  % single query
    if(testID(index(1))==queryID(k));
        count_r1 = count_r1+1;
    end
    [ap(k), CMC(k, :)] = compute_AP(good_index, [], index);% compute AP for single query
end
r1 = count_r1/nQuery;

end