
Meta annotation format:
[camID personID frameIdx x1 x2 y1 y2]


In this dataset, Cam 1 = the 3rd camera in iLIDS; Cam 2 = the 5th camera in iLIDS

For the videos for these people, they seem originally stored in the folder like
i-LIDS-2/MCT TR 02/MCTTR02b/. You may find them according to the meta file name.