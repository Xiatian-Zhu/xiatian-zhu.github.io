This is the demo of the following paper on how to construct affinity graphs.

The random forest inlcuded in this code is a revised version based on the randomforest-matlab project: 
http://code.google.com/p/randomforest-matlab/

The code of spectral clustering algorithm is provided from:
http://www.vision.caltech.edu/lihi/Demos/SelfTuning/ZPclustering.zip

Reference:
[1] Constructing Robust Affinity Graphs for Spectral Clustering
    X. Zhu, C.C. Loy and S. Gong. 
    In Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR), Columbus, Ohio, USA, June 2014.