%% Mex cpp files
%
% @ Author: Eddy Zhu
% @ Date: 21 Feb. 2013

mex evrot.cpp;
mex dist2aff.cpp;
mex scale_dist.cpp;
mex zero_diag.cpp;

disp('=== Mex cpp files Done ...');