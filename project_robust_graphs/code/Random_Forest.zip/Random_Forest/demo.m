%% The demo for constructing random forest based affinity matrices

addpath('RF');


%% TODO: Load data X
X = randn(100, 200);

%% Train a clustering random forest
% Parameters
ntree = 200;
mtry = -1;
extra_options.proximity = 1;
extra_options.nodesize = 1;

RF_model = classRF_train(X, [], ntree, mtry, extra_options);


%% Get affinity matrix
A = RF_model.proximity;
figure(1);
A(eye(size(A,1)) == 1) = 0;
imagesc(A);
title('ClustRF Affinity Matrix');

