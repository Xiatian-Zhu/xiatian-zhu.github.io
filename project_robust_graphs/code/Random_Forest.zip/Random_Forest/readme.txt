See demo.m for an example

04 Nov. 2014
Xiatian Zhu
