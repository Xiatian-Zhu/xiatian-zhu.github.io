%% Test the order transformation of a matrix between Matlab and C++
%   
% @Author: Eddy Zhu
% @Date: 25 Mar. 2013
clc;

mex test_forloop.cpp  -output test_forloop

disp('--- Mex test_forloop.cpp DONE');