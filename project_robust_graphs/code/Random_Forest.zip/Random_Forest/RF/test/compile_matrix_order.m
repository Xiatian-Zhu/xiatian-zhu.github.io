%% Test the order transformation of a matrix between Matlab and C++
%   
% @Author: Eddy Zhu
% @Date: 25 Mar. 2013
clc;

mex test_matrix_order.cpp  -output test_matrix_order

disp('--- Mex test_matrix_order.cpp DONE');