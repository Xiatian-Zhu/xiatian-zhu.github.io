/** Test the order transformation of a matrix between Matlab and C++
 *
 *
 * @Author: Eddy Zhu
 * @Date: 25 Mar. 2013
 */

#include <math.h>
#include "memory.h"
#include "mex.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{ 
   
    for (int j = 0; j < 10; ++j) 
	{
		mexPrintf("%d\n", j);
	}

}
