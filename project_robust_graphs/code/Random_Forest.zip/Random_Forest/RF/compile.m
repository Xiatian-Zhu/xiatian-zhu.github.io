

disp('=== To mex random forest by C++');

% mex src/mex_retrieveSplitVarHist.cpp src/classRF.cpp src/classTree.cpp src/rfutils.cpp src/cokus.cpp src/buildtree.cpp -output retrieve_split_var_hist -lm -DMATLAB -O
% disp('=== mex mex_retrieveSplitVarHist DONE');
% return;

mex src/mex_ClassificationRF_train.cpp  src/classRF.cpp src/classTree.cpp src/rfutils.cpp src/cokus.cpp src/buildtree.cpp -output mexClassRF_train  -lm -DMATLAB -O 
disp('=== mex mex_ClassificationRF_train DONE');

mex src/mex_ClassificationRF_predict.cpp src/classRF.cpp src/classTree.cpp src/rfutils.cpp src/cokus.cpp src/buildtree.cpp -output mexClassRF_predict -lm -DMATLAB -O
disp('=== mex mex_ClassificationRF_predict DONE');

disp('... Great, mex done !!!!!!!!!!!!!!!!!');

