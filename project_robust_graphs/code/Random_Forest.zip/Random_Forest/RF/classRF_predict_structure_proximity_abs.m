%% This function is to predict the structure similarity betwen samples over all the trees in the RF
%
% @Author: Xiatian (Eddy) Zhu
% @Date: 20 September 2013

function [ClustRF_Strct_A] = classRF_predict_structure_proximity_abs(X, classRF_model, affinity_type)


%% Treemap: a variable that holds the treemap
classRF_model.treemap2 = zeros(classRF_model.nrnodes*2,classRF_model.ntree);
for treenum=1:classRF_model.ntree
    classRF_model.treemap2(:,treenum)=[classRF_model.treemap(:,(treenum-1)*2+1); classRF_model.treemap(:,(treenum-1)*2+2)];
end



%% Iterate through each tree
A_path_RF = 0;
tic;
parfor j = 1 : classRF_model.ntree
    [rl_paths, path_lengths] = channel_one_tree(X, classRF_model, j, size(X, 1));
    A_path_tree = calc_path_similarity_abs(rl_paths, path_lengths, affinity_type);
    A_path_RF = A_path_RF + A_path_tree;
    %clear A_path_tree rl_paths path_lengths;
end
et = toc;
fprintf('***ClustRF-strct-abs: Ag, time = %f sec.\n', et);




%% Compute the final structure-based proximity/affinity
%     A_structure = A_path_RF / classRF_model.ntree;
%     A_structure(eye(size(X, 1)) == 1) = 1;

% if(sum(abs(diag(A_path_RF) - A_path_RF(1,1))) > 0)
%     error('The elements on the diag are different...');
% end
% A_structure = A_path_RF / A_path_RF(1,1);

% normalisation
ClustRF_Strct_A = A_path_RF ./ repmat(diag(A_path_RF), 1, size(A_path_RF, 2));

% make it symmetric
ClustRF_Strct_A = (ClustRF_Strct_A + ClustRF_Strct_A') / 2;


clear classRF_model;





%% Compute the similarity between paths
function [A_path] = calc_path_similarity_abs(rl_paths, path_lengths, affinity_type)
    
global CLUSTRF_STRCT_ABS;
global CLUSTRF_STRCT_ACCUMDEPTH; 
global CLUSTRF_STRCT_ACCUMDEPTH_INVERSE;

N = length(rl_paths);

%% Remove redundancy dimensions, save resources
max_path_len = max(path_lengths);
rl_paths(:, max_path_len+1:end) = [];

% paths
P = kron(rl_paths, ones(N, 1));
Q = repmat(rl_paths, N, 1);



sim_paths = P == Q;

switch affinity_type
    
    case CLUSTRF_STRCT_ABS
        % no depth
    
    case CLUSTRF_STRCT_ACCUMDEPTH
        
        % add depth information
        path_depths = 0:size(sim_paths, 2)-1; % Not count the root
        path_depths = repmat(path_depths, size(sim_paths, 1), 1);
        
        sim_paths = path_depths .* sim_paths;
        
        clear path_depths;
        
    case CLUSTRF_STRCT_ACCUMDEPTH_INVERSE
        
        % path length
        P_len = kron(path_lengths, ones(N, 1));
        Q_len = repmat(path_lengths, N, 1);
        lens = [P_len'; Q_len'];
        min_len = min(lens); 
        
        % add inverse depth information
        inverse_path_depths = zeros(size(sim_paths));
        for idx = 1 : size(sim_paths, 2) - 1 % Not count the root
            inverse_path_depths(:, idx+1) = min_len - idx;
        end
        inverse_path_depths(inverse_path_depths<0) = 0;
        
        sim_paths = inverse_path_depths .* sim_paths;
        
        clear inverse_path_depths P_len Q_len lens min_len;
        
        
end


A_path = sum(sim_paths, 2);

A_path = reshape(A_path, N, N);

clear P Q sim_paths;


%% symmetric or not
if(sum(sum(abs(A_path - A_path'))) > 0)
    error('Not symmetric'); 
end



% straightforward code
%             A_path = zeros(N);
%             parfor idx_samp = 1 : N
%                 sim_paths = repmat(rl_paths(idx_samp, :), N, 1) == rl_paths;
%                 sim_current_2_others = sum(sim_paths, 2)';% ./ max([ones(1, N) * path_lengths(idx_samp); path_lengths']);
%                 A_path(idx_samp, :) = sim_current_2_others;
%             end




% %% To pass examples in each tree for getting root-leaf paths
% function [rl_paths, path_lengths] = channel_trees(X, classRF_model, idx_tree)   
% NODE_TERMINAL=-1;
% %     NODE_TOSPLIT =-2;
% %     NODE_INTERIOR=-3;
% 
% N = size(X,1);
% 
% rl_paths = zeros(N);
% path_lengths = zeros(N, 1);
% 
% for idx_samp = 1 : N
%     k = 1;
%     path_ins = ones(1, N) * -10 * idx_samp;
%     % start with k=1 and then go on till we reach a terminal node
%     % nodestatus is i think numnodes x numberof trees
%     path_len = 0;
%     while (classRF_model.nodestatus(k,idx_tree) ~= NODE_TERMINAL)
%         % m is the variable that was used to split
%         m = classRF_model.bestvar(k,idx_tree);
% 
%         % now that we know m we can find if X(current_example,m) <= the split value
%         %then either go right or left in the tree.           
%         % if the X's value is less then the split go left, else go right
%         if X(idx_samp,m)  <= classRF_model.xbestsplit(k,idx_tree)
%             %k = treemap((k-1)*2+1);
%             k = classRF_model.treemap2((k-1)*2+1,idx_tree);
%         else
%             %k = treemap((k-1)*2+2);
%             k = classRF_model.treemap2((k-1)*2+2,idx_tree);
%         end
%         path_len = path_len + 1;
%         path_ins(path_len) = k;
% 
%     end
% 
%     path_lengths(idx_samp) = path_len;
%     rl_paths(idx_samp, :) = path_ins;        
% end

    
    
