
Compile random forest:
run ‘compile.m’ in MATLAB

See demo.m for an example

