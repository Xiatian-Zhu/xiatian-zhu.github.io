%% The demo for constructing random forest based affinity matrices

addpath('RF');


%% TODO: Load data X
X = randn(100, 200);

% TODO: labels. 1 - same, 2 - different
Y = [];

%% Train a random forest
% Parameters
ntree = 1000;
mtry = -1;
extra_options.proximity = 1;
extra_options.nodesize = 1;


RF_model = classRF_train(X, Y, ntree, mtry, extra_options);


%% Testing
% TODO: set X_test
X_test = [];
[~, votes, ~, ~, ~, ~] = classRF_predict(RF_model, X_test);

% similarity score
similarity_score = votes(:, 1) / ntree;

