
%% To get tree code for given samples
%
function [tree_code] = get_tree_code(X, RF_model, idx_tree)


NODE_TERMINAL=-1;
%     NODE_TOSPLIT =-2;
%     NODE_INTERIOR=-3;
N = size(X,1);


%% To obtain leaf ID
leaf_ID = zeros(N, 1);

for idx_samp = 1 : N
    k = 1;
    % start with k=1 and then go on till we reach a terminal node
    % nodestatus is i think numnodes x numberof trees
    while (RF_model.nodestatus(k,idx_tree) ~= NODE_TERMINAL)
        % m is the variable that was used to split
        m = RF_model.bestvar(k,idx_tree);

        % now that we know m we can find if X(current_example,m) <= the split value
        %then either go right or left in the tree.           
        % if the X's value is less then the split go left, else go right
        if X(idx_samp,m)  <= RF_model.xbestsplit(k,idx_tree)
            %k = treemap((k-1)*2+1);
            k = RF_model.treemap2((k-1)*2+1,idx_tree);

        else
            %k = treemap((k-1)*2+2);
            k = RF_model.treemap2((k-1)*2+2,idx_tree);

        end

    end

    leaf_ID(idx_samp) = k;  

end
    
%% To 
leaf_set = find(RF_model.nodestatus(:, idx_tree) == NODE_TERMINAL);
leaf_set = sort(leaf_set);

% No repeatition
if( length( unique(leaf_set)) ~= length(leaf_set))
    error('repeated in leaf_set');
end

leaf_set_ = repmat(leaf_set', N, 1);

leaf_ID_ = repmat(leaf_ID, 1, length(leaf_set));

tree_code = leaf_set_ == leaf_ID_;

% sanity check on tree code
if(sum(sum(tree_code, 2) == 1) ~= N)
    error('some code is error'); 
end




