%% Test case of constrained clustering forest
% Test the effective of both continuous and discrete constraints using toy data
%
% @Author: Xiatian(Eddy) Zhu
% @Date: 2 Mar 2013


clc;
% close all;
addpath('../');


%% Parameters
num_it = 1;
ntree = 1000;


%% Syntheric data, four Gaussian distributions
num_group = 200;
num_clusters = 4;

dim = 4;
sigma = eye(dim);

rg1 = mgd(num_group, dim, [0 zeros(1, dim-1)], sigma); 
rg2 = mgd(num_group, dim, [50 zeros(1, dim-1)], sigma);
rg3 = mgd(num_group, dim, [0 100 zeros(1, dim-2)], sigma);
rg4 = mgd(num_group, dim, [50 100 zeros(1, dim-2)], sigma);

data = [rg1; rg2; rg3; rg4];

     
%% Variables about non-visual data
% Discrete and continuous non-visual data
Y_nv_src_discrete = [ones(1, num_group * 1) ones(1, num_group) 2*ones(1, num_group * 1) 2*ones(1, num_group);]';

Y_nv_src_continuous = [0.5*rand(1, num_group) 0.5*rand(1, num_group) 0.5+0.5*rand(1, num_group) 0.5+0.5*rand(1, num_group)]';

% The weight of non-visual sources
alpha_nv_src = 0.5;




%% To perform clustering with forest
extra_options.Y_nv_src_discrete = Y_nv_src_discrete;
extra_options.Y_nv_src_continuous = Y_nv_src_continuous;

extra_options.importance = 0;
extra_options.localImp = 0;
extra_options.proximity = 1;
extra_options.keep_inbag = 0; % for debug in VS
extra_options.nodes = 1;
extra_options.replace = 1;
extra_options.nodesize = 5;
mtry = ceil(sqrt(dim));

prox_visual_only = 0;
prox_nv_src_continuous = 0;
prox_nv_src_discrete = 0;
prox_both_nv_src = 0;

for it = 1 : num_it
    %% without constraint
    extra_options.alpha_nv_src_discrete = 0;
    extra_options.alpha_nv_src_continuous = 0;
    tic;
    forest_visual_only = classRF_train(data, [], ntree, mtry, extra_options);
    prox_visual_only = prox_visual_only + forest_visual_only.proximity;
    toc;


    %% with discrete non-visual data: 1&2, 3&4
    extra_options.alpha_nv_src_discrete = alpha_nv_src;
    extra_options.alpha_nv_src_continuous = 0;
    tic;
    forest_nv_discrete = classRF_train(data, [], ntree, mtry, extra_options);
    prox_nv_src_discrete = prox_nv_src_discrete + forest_nv_discrete.proximity;
    toc;


%     %% with continuous non-visual data: 1&2, 3&4
%     extra_options.alpha_nv_src_discrete = 0;
%     extra_options.alpha_nv_src_continuous = alpha_nv_src;
%     tic;
%     forest_nv_continuous = classRF_train(data, [], ntree, mtry, extra_options);
%     prox_nv_src_continuous = prox_nv_src_continuous + forest_nv_continuous.proximity;
%     toc;
% 
%     
%     %% with both non-visual data: 1&2, 3&4
%     extra_options.alpha_nv_src_discrete = alpha_nv_src;
%     extra_options.alpha_nv_src_continuous = alpha_nv_src;
%     tic;
%     forest_nv_both = classRF_train(data, [], ntree, mtry, extra_options);
%     prox_both_nv_src = prox_both_nv_src + forest_nv_both.proximity;
%     toc;
end

prox_visual_only = prox_visual_only / num_it;

prox_nv_src_discrete = prox_nv_src_discrete / num_it;
prox_nv_src_continuous = prox_nv_src_continuous / num_it;
prox_both_nv_src = prox_both_nv_src / num_it;

%% Visualization

% show data points
% figure;
% hold on;
% scatter(rg1(:,1), rg1(:,2), 10, 'r');
% scatter(rg2(:,1), rg2(:,2), 10, 'g');
% scatter(rg3(:,1), rg3(:,2), 10, 'b');
% scatter(rg4(:,1), rg4(:,2), 10, 'k');
% hold off;
% title(['Toy data, dim = ' num2str(dim)], 'FontSize', 20);
% colorbar;
% box on;

figure;
subplot(2,2,1);
imagesc(prox_visual_only);
colorbar;
title('No Constraint', 'FontSize', 20);

subplot(2,2,2);
imagesc(prox_nv_src_discrete);
colorbar;
title(['1&2, 3&4, Discrete (' num2str(alpha_nv_src) ')'], 'FontSize', 20);

subplot(2,2,3);
imagesc(prox_nv_src_continuous);
colorbar;
title(['1&2, 3&4, Continuous (' num2str(alpha_nv_src) ')'], 'FontSize', 20);

subplot(2,2,4);
imagesc(prox_both_nv_src);
colorbar;
title(['1&2, 3&4, Both (' num2str(2*alpha_nv_src) ')'], 'FontSize', 20);

set(gcf, 'name', 'Regression+Classification, Affinity Matrix');
%set(gcf, 'Position', get(0,'ScreenSize'));

