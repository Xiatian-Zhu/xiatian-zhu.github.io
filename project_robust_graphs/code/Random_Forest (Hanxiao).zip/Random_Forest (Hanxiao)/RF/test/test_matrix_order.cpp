/** Test the order transformation of a matrix between Matlab and C++
 *
 *
 * @Author: Eddy Zhu
 * @Date: 25 Mar. 2013
 */

#include <math.h>
#include "memory.h"
#include "mex.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{ 
    mexPrintf("~~~ Hello, I am here \n");
    int rows = (int)mxGetScalar(prhs[0]); 
    int cols = (int)mxGetScalar(prhs[1]); 
    double rows_d = (double)mxGetScalar(prhs[2]); 
    double cols_d = (double)mxGetScalar(prhs[3]); 
    mexPrintf("~~~ rows = %d, cols = %d, rows_d = %f, cols_d = %f \n", rows, cols, rows_d, cols_d);
	
	if(rows != rows)
        mexPrintf("~~~ rows, pass\n");
    
    if(cols != cols)
        mexPrintf("~~~ cols, pass\n");
    
    if(rows_d != rows_d)
        mexPrintf("~~~ rows_d, pass\n");
    
    if(cols_d != cols_d)
        mexPrintf("~~~ cols_d, pass\n");
    
    return;
    
    
    if(rows <= 0 || cols <= 0)
    {
        mexPrintf("$$$ Invalid parameters: rows=%d, cols=%d\n", rows, cols);
        return;
    }
    plhs[0] = mxCreateNumericMatrix(rows, cols, mxDOUBLE_CLASS, mxREAL);
    double *meanSurrVarAssoc = (double*) mxGetData(plhs[0]);
    
    for (int idx = 0; idx < rows * cols; idx++)
    {
        mexPrintf("--- meanSurrVarAssoc[%d] = %d \n", idx, idx + 1);
        meanSurrVarAssoc[idx] = idx + 1;
    }
    
    mexPrintf("~~~ Hello, I am here, almost finish my job ... \n");
}
