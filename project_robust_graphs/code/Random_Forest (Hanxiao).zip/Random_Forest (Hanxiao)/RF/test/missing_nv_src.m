%% Test cases with different acount of missing nv-source data
% 
% @Author: Xiatian(Eddy) Zhu
% @Date: 27 Mar. 2013


clc;
close all;
addpath('../');


%% Parameters
num_it = 1;
ntree = 100;


%% Syntheric data, four Gaussian distributions
num_group = 200;
num_clusters = 4;

dim = 10;
sigma = eye(dim);

rg1 = mgd(num_group, dim, [0 zeros(1, dim-1)], sigma); 
rg2 = mgd(num_group, dim, [50 zeros(1, dim-1)], sigma);
rg3 = mgd(num_group, dim, [0 100 zeros(1, dim-2)], sigma);
rg4 = mgd(num_group, dim, [50 100 zeros(1, dim-2)], sigma);

data = [rg1; rg2; rg3; rg4];

     
%% Variables about non-visual data
% Discrete and continuous non-visual data
discrete_nonvisual_data = [ones(1, num_group * 1) ones(1, num_group) 2*ones(1, num_group * 1) 2*ones(1, num_group);]';

continuous_nonvisual_data = [0.5*rand(1, num_group) 0.5*rand(1, num_group) 0.5+0.5*rand(1, num_group) 0.5+0.5*rand(1, num_group)]';

%% 
ratio_sample_missing_nv_src = 0;
if(ratio_sample_missing_nv_src > 0)
    disp(['!!!!! The rate of missing Non-Visual data: ' num2str(ratio_sample_missing_nv_src)]);
    % The up-bound is 100%


    num_nv_src_discrete = size(discrete_nonvisual_data, 2);
    num_nv_src_continuous = size(continuous_nonvisual_data, 2);
    num_nv_src = num_nv_src_discrete + num_nv_src_continuous;

    % The samples to be with missing nv-src data
    num_samples = size(data, 1);
    idx_sample_missing_nv_src = [];
    num_sample_missing_nv_src = floor(num_samples * ratio_sample_missing_nv_src);
    enough_sample = 0;
    while(enough_sample == 0)
        idx_sample_missing_nv_src = [idx_sample_missing_nv_src; randi(num_samples, num_sample_missing_nv_src, 1)];
        idx_sample_missing_nv_src = unique(idx_sample_missing_nv_src, 'stable');
        if(length(idx_sample_missing_nv_src) >= num_sample_missing_nv_src)
            idx_sample_missing_nv_src = idx_sample_missing_nv_src(1:num_sample_missing_nv_src, 1);
            enough_sample = 1;
        end
    end

    for idx_sample_selected = 1 : length(idx_sample_missing_nv_src)
        idx_sample = idx_sample_missing_nv_src(idx_sample_selected);
        % The random number of nv-src to be missing
        num_missing_nv_src = randi(num_nv_src, 1, 1);
        % The index of nv-src to be missing
        idx_missing_nv_src = randi(num_nv_src, 1, num_missing_nv_src);
        idx_missing_nv_src = unique(idx_missing_nv_src);
        for idx_nv = 1 : length(idx_missing_nv_src)
            idx_nv_src = idx_missing_nv_src(idx_nv);
            if(idx_nv_src <= num_nv_src_discrete)
                discrete_nonvisual_data(idx_sample, idx_nv_src) = -1; % class label : -1
            else
                continuous_nonvisual_data(idx_sample, idx_nv_src - num_nv_src_discrete) = NaN;
            end
        end
    end
end

%% The weight of non-visual sources
alpha_nv_src = 0.5;




%% To perform clustering with forest
extra_options.Y_nv_src_discrete = discrete_nonvisual_data;
extra_options.Y_nv_src_continuous = continuous_nonvisual_data;

extra_options.alpha_nv_src_discrete = alpha_nv_src;
extra_options.alpha_nv_src_continuous = 0;

extra_options.importance = 0;
extra_options.localImp = 0;
extra_options.proximity = 1;
extra_options.keep_inbag = 0; % for debug in VS
extra_options.nodes = 1;
extra_options.replace = 1;
extra_options.nodesize = 2;
mtry = ceil(sqrt(dim));

prox_01 = 0;
prox_07 = 0;
prox_04 = 0;
prox_10 = 0;

for it = 1 : num_it
    %% missing 10%
    extra_options.ratio_sample_missing_nv_src = 0.1;
    tic;
    forest_visual_only = classRF_train(data, [], ntree, mtry, extra_options);
    prox_01 = prox_01 + forest_visual_only.proximity;
    toc;

%     %% missing 40%
%     extra_options.ratio_sample_missing_nv_src = 0.4;
%     tic;
%     forest_nv_discrete = classRF_train(data, [], ntree, mtry, extra_options);
%     prox_04 = prox_04 + forest_nv_discrete.proximity;
%     toc;
% 
% 
%     %% missing 70%
%     extra_options.ratio_sample_missing_nv_src = 0.7;
%     tic;
%     forest_nv_continuous = classRF_train(data, [], ntree, mtry, extra_options);
%     prox_07 = prox_07 + forest_nv_continuous.proximity;
%     toc;
% 
%     
%     %% missing 100%
%     extra_options.ratio_sample_missing_nv_src = 1;
%     tic;
%     forest_nv_both = classRF_train(data, [], ntree, mtry, extra_options);
%     prox_10 = prox_10 + forest_nv_both.proximity;
%     toc;
end

prox_01 = prox_01 / num_it;

prox_04 = prox_04 / num_it;
prox_07 = prox_07 / num_it;
prox_10 = prox_10 / num_it;

%% Visualization

figure;
subplot(2,2,1);
imagesc(prox_01);
colorbar;
title('Missing 0.1', 'FontSize', 20);

subplot(2,2,2);
imagesc(prox_04);
colorbar;
title('Missing 0.4', 'FontSize', 20);

subplot(2,2,3);
imagesc(prox_07);
colorbar;
title('Missing 0.7', 'FontSize', 20);

subplot(2,2,4);
imagesc(prox_10);
colorbar;
title('Missing 1.0', 'FontSize', 20);

set(gcf, 'name', 'Regression+Classification, Affinity Matrix');
set(gcf, 'Position', get(0,'ScreenSize'));

