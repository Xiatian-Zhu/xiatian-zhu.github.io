%% Test the order transformation of a matrix between Matlab and C++
% Additional:
%   1. the maximum Int value that allows to transfer between Matlab and C++
%   2. 
%   
% @Author: Eddy Zhu
% @Date: 25 Mar. 2013

%clc;

mat_order = test_matrix_order(NaN, Inf, NaN, Inf);
disp(mat_order);

