#ifndef QSORT_H
#define QSORT_H

void R_qsort_I(double *v, int *I, int i, int j);

#endif