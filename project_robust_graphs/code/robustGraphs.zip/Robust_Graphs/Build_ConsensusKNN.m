function [ prob_trans_mat ] = build_consensus_knn( knn_graph )
%BUILD_CONSENSUS_KNN Summary of this function goes here
%   Detailed explanation goes here
% build a consensus knn based on a given symmetric sparse knn graph

N = size(knn_graph, 1);

cons_mat = zeros(N, N);
        
for idx_samp = 1 : N
    % The kNN of the current sample
    cur_samp_knn = knn_graph(idx_samp, :);
    cur_knn_idx = find(cur_samp_knn ~= 0);

    % Accumulate the number of time a node pair occuring in the KNN
    if 1 % Eddy's implementation
        for row_idx = 1 : length(cur_knn_idx)
            samp_row_idx = cur_knn_idx(row_idx);
            for col_idx = row_idx+1 : length(cur_knn_idx)
                samp_col_idx = cur_knn_idx(col_idx);
                cons_mat(samp_row_idx, samp_col_idx) = cons_mat(samp_row_idx, samp_col_idx) + 1;
                cons_mat(samp_col_idx, samp_row_idx) = cons_mat(samp_col_idx, samp_row_idx) + 1;
            end
        end
        
    elseif 0 % the original psuedo code
        for row_idx = 1 : N
            for col_idx = row_idx+1 : N
                com_el = intersect(cur_knn_idx, [row_idx col_idx]);
                if(length(com_el) == 2)
                    cons_mat(row_idx, col_idx) = cons_mat(row_idx, col_idx) + 1;
                    cons_mat(col_idx, row_idx) = cons_mat(col_idx, row_idx) + 1;
                end
            end
        end

    else % Cavan's implementation

        F = zeros(N); % say this is your initial frequency matrix
        P = nchoosek(cur_knn_idx, 2); % you can get all the neighbour pairs like this 
        linearP = sub2ind(size(F), P(:,1), P(:,2)); % change to linear index
        F(linearP) = 1;
        F = max(F, F'); % make it symmetric
        cons_mat = cons_mat + F;
    end

end

% check if the consensus matrix is symmetric
if(sum(sum(abs(cons_mat - cons_mat'))) > 0)
    error('>>> The consensus matrix is NOT symmetric ....');
end

%% Transform the consensus matrix to a probabilistic trainstion matrix

% Row normalisation -> probabilitic transition matrix, non-symmetric output
cons_mat_norm = cons_mat ./ repmat(sum(cons_mat, 2), 1, N);

% Thresholding, G', remove noisy links with low probabilities
%         tau = mean(cons_mat_norm(:)); % its setting not found in paper ??????????
%         true_NN_indicator = cons_mat_norm >= tau;
%         cons_mat_norm_thresh = cons_mat_norm .* true_NN_indicator;

% As said by the authors, \tau is only used to generalise the
% method, and it is set to 0 in their evaluations. We do so as well
cons_mat_norm_thresh = cons_mat_norm;

% To probabilitic transition matrix, the sum of each row = 1
prob_trans_mat = cons_mat_norm_thresh ./ repmat(sum(cons_mat_norm_thresh, 2), 1, N);

% make it symmetric
prob_trans_mat = max(prob_trans_mat, prob_trans_mat');


end

