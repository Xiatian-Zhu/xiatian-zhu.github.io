function Output = DominantNeighbors(A, Thresh, stop_th, select_th, KNN)

if nargin>4
    NN_Flag = 1;
else
    NN_Flag = 0;
end
Output = zeros(size(A));
SIZE = length(A);
Initials = A > Thresh;

parfor k = 1:SIZE
    Incre = 10;
%     if ~NN_Flag
%         %Initial = A(k,:)>Thresh;
%     else
%         %[v,idx] = sort(A(k,:),'descend');
%         %Initial = idx(1:KNN);
%     end
    x = zeros(SIZE,1);
    x(Initials(k,:)) = 1;
    x = x/sum(x);
    while Incre > stop_th
        Ax = A*x;
        Old_Tar = x'*Ax;
        x = x.*((Ax)/(Old_Tar));
        Incre = x'*A*x - Old_Tar;
    end
    Output(k,:) = x>select_th;
end
