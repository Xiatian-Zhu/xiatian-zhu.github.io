

%% train a random forest
% load data X, Y
% X: a NxD matrix, N - the number of samples, D - the feature dimension
load fisheriris
X = meas;
Y = [ones(50,1); 2*ones(50,1); 3*ones(50,1)];

num_trees = 100;
minleaf = 1;
RF = TreeBagger(num_trees, X, Y, 'method', 'r', 'oobpred', 'on', 'oobvarimp', 'on', 'minleaf', minleaf );


%% Generate forest codes for testing samples
X_test = X(1:10, :);
code_RF = gen_code_with_forest(RF, X_test);

% To concatenate tree-level sub-code into the final forest code
forest_codes = [];
for idx_samp = 1 : size(X_test, 1)
	codes_samp = code_RF{idx_samp, 1};
    forest_codes = [forest_codes; cell2mat(codes_samp)];
end


