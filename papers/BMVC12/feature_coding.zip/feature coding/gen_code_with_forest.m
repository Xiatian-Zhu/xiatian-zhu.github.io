function codes = gen_code_with_forest(RF, X_test)

%% parameters:
% input:
% -- RF: the random forest (TreeBagger)
% -- X_test: the matrix of observation, each row indicates a data
%                observation/point/sample
% 
% output:
% -- codes: each element/row corresponds the code for the corresponding data point. 
%               Each code is a collection of T tree-level sub-code stored separately in a row vector, 
%               where T is the number of trees.
% 
% @Author: Xiatian Zhu
% @Date: Sep. 2012

%% ----------------- Begin --------------------------------------------------

% get the leaf index of a tree
trees = RF.Trees;
num_trees = length(trees);
leaf_index_array = cell(1, num_trees);
for index_tree = 1 : num_trees
    br = isbranch(trees{index_tree});
    leaf_index = find((br == 0));
    leaf_index_array{index_tree} = leaf_index';
end

num_obs = size(X_test, 1);
codes = cell(num_obs, 1);
% each loop: compute code for one observation
for index_obs = 1 : num_obs
    code_per_obs = cell(1, num_trees);
    try
        for index_tree = 1 : num_trees
            % find the node index making prediction for the given new data
            [yfit, node_index] = eval(trees{index_tree}, X_test(index_obs,:));
            % code based on node_index
            cur_leaf_index = leaf_index_array{index_tree};
            [row leaf_index] = find(node_index - 1 < cur_leaf_index & ...
                                     cur_leaf_index < node_index + 1);
            code = zeros(1, length(cur_leaf_index));
            code(leaf_index) = 1;
            code_per_obs{index_tree} = code;
        end
    catch me
        fprintf(me.message);
    end
    
    codes{index_obs, 1} = code_per_obs;
end

end

