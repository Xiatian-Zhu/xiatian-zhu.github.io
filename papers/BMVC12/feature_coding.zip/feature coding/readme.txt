This is the demo of the following paper on how to perform feature coding using random forest for learning disjoint camera dependencies.

Reference:
[1] X. Zhu, S. Gong and C.C. Loy. Comparing Visual Feature Coding for Learning Disjoint Camera Dependencies . In Proc. British Machine Vision Conference (BMVC), Guildford, UK, September 2012.