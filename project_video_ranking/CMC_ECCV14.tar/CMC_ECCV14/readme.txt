The CMC scores by our DVR model on the iLIDS-VID and PRID2011 datasets.
Also the results by MS-Colour+DVR are included, see Table 3 of the paper below.

Format: mat file (Matlab)

Reference:
Person Re-Identification by Video Ranking. 
T. Wang, S. Gong, X. Zhu and S. Wang.	
In Proc. European Conference on Computer Vision (ECCV), Zurich, Switzerland, September 2014. 

