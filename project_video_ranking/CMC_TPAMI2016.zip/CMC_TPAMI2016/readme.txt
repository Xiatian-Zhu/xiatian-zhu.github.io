The CMC scores by our DVR model, baseline methods and fused ones on the iLIDS-VID and PRID2011 datasets.

Reference:
Person Re-Identification by Discriminative Selection in Video Ranking
T. Wang, S. Gong, X. Zhu and S. Wang.	
IEEE Transactions on Pattern Analysis and Machine Intelligence, in print, 2016.
