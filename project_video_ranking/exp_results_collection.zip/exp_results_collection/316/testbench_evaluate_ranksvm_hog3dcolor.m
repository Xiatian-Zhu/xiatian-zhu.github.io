% testbench_optimize_penalty_hog3d:
% SS- , MS-HOG3DColor + RankSVM
% Added by Eddy
%
% use Expected Rank as measure
close all
clear all
clc

start_t = clock;
addpath('../');
global_vars();
global Data_path;
global Dataset_path;

%%
dataset_name =  'ilidsvid' %'ilidsvid'; % 'prid'; %

% how much data used for model training
% kept_train_ratio = 1/10;

% cam_a as probe, cam_b as gallery
camera_set = {'cam1', 'cam2'};

%% SS- or MS-
SS_case = 0;
if SS_case
    feat_path = [Data_path 'RankSVM/' dataset_name '/single_shot/HOG3D_color/']; %[datapath, 'colorfeat/']
    %method_name = 'SS_HOG3DColor_RankSVM';
else 
    feat_path = [Data_path 'RankSVM/' dataset_name '/multi_shot/HOG3D_color/']; %[datapath, 'colorfeat/']
    snippet_num = 8;
    %feat_path = [Data_path 'RankSVM/' dataset_name '/multi_shot/HOG3D_color/' num2str(snippet_num) 'perSeq']; %[datapath, 'ms_HOG3DbmColor/'];
    %method_name = 'MS_HOG3DColor_RankSVM';
end



%% 
% datapath = '../data3/';
% feat_path = [datapath, 'ss_HOG3DbmColor/']

nfold = 10; % actually repeat

test_ratio = 0.5; % ratio of data for testing

penalty= 1e-6;

rank_of_interest = [1 5 10 20 50];

%%
cpuCoreNum = nfold;
if matlabpool('size') ~= cpuCoreNum
    matlabpool close force
    matlabpool('open', 'local', cpuCoreNum);
end

%% Use fixed split for training and testing
splitfile = [Dataset_path dataset_name '/cv_split.mat']
if exist(splitfile, 'file')
    vars = load(splitfile);
    ls_set = vars.ls_set;
else
    error(' ');
end

%% Count the number of people in the dataset
personidset = [];
list = dir(feat_path);
for i = 3 : numel(list)
    str = list(i).name;
    idxs = find(str == '_');
    personid = str2num(str(idxs(1)+7 : idxs(1)+9));
    personidset = [personidset, personid];
end
personidset = unique(personidset);
pidset = personidset;

np = numel(personidset); % #person
nperson = np;
nptest = floor(np*test_ratio); % #person for test
nptrain = np - nptest;
% ******** change the number of training persons ******
% nptrain = round( (nperson - nptest) * kept_train_ratio); %

fprintf('total person: %d, train: %d test: %d. \n', nperson, nptrain, nptest);

%% method name
if SS_case
    method_name = 'SS_HOG3DColor_RankSVM';
else
    %method_name = 'MS_HOG3DColor_RankSVM';
    method_name = sprintf('MS_HOG3DColor_RankSVM_%dperSeq_trainN=%d', snippet_num, nptrain);
end

fprintf('\n\n** %s, %s\n\n', method_name, dataset_name);


%% load all the feature data
list = dir(feat_path);
nsample = numel(list)-2;
names = cell(nsample, 1);
vars = load([feat_path, list(3).name]);
dim = numel(vars.hog3d) + numel(vars.bmColor);
feat_set = zeros(nsample, dim, 'single');
for i = 3 : numel(list)
    names{i-2} = list(i).name;
    vars = load([feat_path, list(i).name]);
    feat_set(i-2,:) = [vars.hog3d vars.bmColor];
end

dim = size(feat_set, 2);

fprintf('feat dim = %d\n', dim);

%% normalizefeat in column-wise way
feat_set = normalizefeat(feat_set);

%%
disp(['*** penalty = ', num2str(penalty)])
%% cross validation
rates_folds = zeros(1, nptest);
nauc_folds = 0;
er_folds = 0;
parfor fold_idx = 1 : nfold
    disp(['repeat idx = ', num2str(fold_idx)]);
    %test_person_set = personidset(nptest*(fold_idx-1)+1 : nptest*fold_idx);
    %         tmp = randperm(np);
    %         rand_person_set = personidset(tmp);
    %         test_person_set = rand_person_set(1:nptest);
    %         train_person_set = setdiff(personidset, test_person_set);
    
    ls = ls_set(fold_idx, :);
    nptest = round(test_ratio*nperson);
    disp(['nptest = ', num2str(nptest)])
    pidset_test = pidset(ls(1:nptest));
    pidset_train = setdiff(pidset, pidset_test);
    
    % ******** change the number of training persons ******
    pidset_train = pidset_train(1:nptrain);
    
    test_person_set = pidset_test;
    train_person_set = pidset_train;
    
    disp(['test person: ', num2str(numel(test_person_set))])
    disp(['train person: ', num2str(numel(train_person_set))])
    
    %% create training data for ranksvm
    nsample = nptrain*nptrain;
    npair = nptrain*(nptrain-1);
    X = zeros(nsample, dim, 'single'); % see ranksvm.m
    A = zeros(npair, nsample, 'single');
    serial = 0;
    pair = 0;
    for p = train_person_set
        name1 = ['hog3dbmColor_person', strconv(p, 3), '_', camera_set{1}, '.mat'];
        idx1 = search_str(names, name1);
        feat1 = feat_set(idx1, :);
        name2 = ['hog3dbmColor_person', strconv(p, 3), '_', camera_set{2}, '.mat']; % feature of the same person in camera b
        idx2 = search_str(names, name2);
        feat2 = feat_set(idx2, :);
        serial = serial + 1;
        X(serial, :) = abs(feat1 - feat2);
        ps = serial;
        for p2 = setdiff(train_person_set, p)
            name2 = ['hog3dbmColor_person', strconv(p2, 3), '_', camera_set{2}, '.mat']; % feature of the same person in camera b
            idx2 = search_str(names, name2);
            feat2 = feat_set(idx2, :);
            serial = serial + 1;
            X(serial, :) = abs(feat1 - feat2);
            pair = pair + 1;
            A(pair, ps) = +1;
            A(pair, serial) = -1;
        end
    end
    
    %% train ranksvm
    w = ranksvm(X, A, penalty*ones(pair, 1));
    
    numel(w);
    
    %% evaluate ranksvm
    score_mat = zeros(nptest, nptest);
    for p = test_person_set
        name1 = ['hog3dbmColor_person', strconv(p, 3), '_', camera_set{1}, '.mat'];
        idx1 = search_str(names, name1);
        feat1 = feat_set(idx1, :);
        for p2 = test_person_set
            name2 = ['hog3dbmColor_person', strconv(p2, 3), '_', camera_set{2}, '.mat']; % feature of the same person in camera b
            idx2 = search_str(names, name2);
            feat2 = feat_set(idx2, :);
            score_mat(test_person_set == p, test_person_set == p2) = abs(feat1 - feat2)*w;
        end
    end
    ranks = zeros(1, nptest);
    for i = 1 : numel(test_person_set)
        pscore = score_mat(i, i);
        idx = find(sort(score_mat(i, :), 'descend') == pscore);
        ranks(i) = idx(1);
    end
    
    rates = zeros(1, nptest); % match rates for each rank thresh
    for rank = 1 : nptest
        rates(rank) = 100 * sum(ranks <= rank) / nptest;
    end
    nauc = sum(rates/100) / nptest;
    er = mean(ranks);
    
    disp(['--- fold ', num2str(fold_idx), ' validation ---']);
    disp(['nauc = ', num2str(nauc)]);
    %disp(['expected rank = ', num2str(er), ' / ', num2str(nptest)])
    %disp('ranks for each probe subject: ');
    %disp(ranks)
    
    rates_folds = rates_folds + rates;
    nauc_folds = nauc_folds + nauc;
    er_folds = er_folds + er;
    
end

%% 
result_path = ['../results/' dataset_name '/RankSVM/'];
if(~exist(result_path, 'dir'))
    mkdir(result_path); 
end

%% plot CMC
nptest = round(test_ratio*nperson);
disp('Final averaged results:');
rates = rates_folds / nfold;
nauc = nauc_folds / nfold;
er = er_folds / nfold;
%     disp(' > RANKSVM')
disp(['penalty = ', num2str(penalty)]);
disp(['nauc = ', num2str(nauc)]);
%     disp(['expected rank = ', num2str(er), ' / ', num2str(nptest)])
for rank = rank_of_interest
    disp(['rank ', num2str(rank), ' : ', num2str(rates(rank)), '%']);
end

figure;
plot(1:nptest, rates, '-rs', 'linewidth', 2);
axis([1, nptest, 0, 100]);
xlabel('rank');
ylabel('match rate (%)');
grid;
%%
stop_t = clock;
timecost = etime(stop_t, start_t);
disp(['Time cost = ', num2str(timecost/60), ' mins']);


%%
save([result_path 'rates_' method_name '.mat'], 'rates', 'nauc', 'er', 'penalty', 'nptest', 'nfold', 'nperson', 'test_ratio');

fprintf('\n%s: done on %s\n\n', method_name, dataset_name);