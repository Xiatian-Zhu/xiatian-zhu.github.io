% testbench_primal_miranksvm_exact_supportdnsamplebag_simoutput
% output dist matrix for combination with other methods
close all force
clear all
clc

start_t = clock;

addpath('../');
global_vars();
global Data_path;
global Dataset_path;

%%
dataset_name = 'ilidsvid';% 'prid'; % 'prid'; % 

kept_train_ratio = 1/1; %1; 3/4; 2/3; 1/2; 1/3; 1/4; 1/5; 1/10

% maxNumFragPerSeq = 3;

%% feature type
feat_type = 'hog3dcolour';% 'hog3dcolourlbp'; % 'hog3dcolour'; % 'hog3d'; %
switch feat_type
    case 'hog3d'
        feat_file_prefix = [Data_path, 'MIRank/', dataset_name, '/features/hog3d/normed_hog3d_cam'];   
    case 'hog3dcolour'
        feat_file_prefix = [Data_path, 'MIRank/', dataset_name, '/features/normed_hog3dColour_cam']; 
    case 'hog3dcolourlbp'
        feat_file_prefix = [Data_path, 'MIRank/', dataset_name, '/features/normed_hog3dColourLBP_cam']; 
end

%%
train_ratio = 0.5;
test_ratio = 0.5;

% downsampling ratio of bag-
%dnr = 1;%0.1;

penalty = 1e-6;

maxiter = 5;
dw = 1e-5;

rank_of_interest = [1 5 10 20];

% number of cross validations
nfold = 10;

%% set random seed
% s = RandStream('mt19937ar', 'Seed', 1);
% RandStream.setGlobalStream(s);
rs = RandStream.create('mrg32k3a', 'NumStreams', nfold, 'Seed', 0, 'celloutput', true);

%%
cpuCoreNum = nfold;
if matlabpool('size') ~= cpuCoreNum && cpuCoreNum > 1
    matlabpool close force
    matlabpool('open', 'local', cpuCoreNum);
end


%% load feature data
% data from cam 1
vars = load([feat_file_prefix, '1.mat']);
% vars = load([feat_file_prefix, '1','_maxNumFragPerSeq', num2str(maxNumFragPerSeq), '.mat']);
% [person, cam, vid, feat]
X1 = vars.X;
% data from cam2
vars = load([feat_file_prefix, '2.mat']);
% vars = load([feat_file_prefix, '2', '_maxNumFragPerSeq', num2str(maxNumFragPerSeq), '.mat']);
% [person, cam, vid, feat]
X2 = vars.X;

disp(['feature dim = ', num2str(size(X1,2)-3)]);

pidset = unique(X1(:,1));
nperson = numel(pidset);
disp(['total number of person = ', num2str(nperson)]);
nptest = round(test_ratio*nperson);
% ******** change the number of training persons ******
nptrain =  round( (nperson - nptest) * kept_train_ratio); %

fprintf('total person: %d, train: %d test: %d. \n', nperson, nptrain, nptest);

% downsampling ratio of bag-, and the number of negative instances is about
% 100 for each person/box. Whilst the number of positive instances is about
% 30 - 36
warning('!dnr')
dnr = 0.1;%min(1, 100 / (30*nptrain)); % 0.1;
fprintf('downsampling ratio of negative instances: %.3f\n', dnr);

%% method name
switch feat_type
    case 'hog3d'
        method_name = sprintf('HOG3D_DVR_exact_1perSeq_trainN=%d', nptrain); % 'HOG3D_DVR_exact_1perSeq';
    case 'hog3dcolour'
        method_name = sprintf('HOG3DColour_DVR_exact_1perSeq_trainN=%d', nptrain); % 'HOG3DColour_DVR_exact_1perSeq';  
    case 'hog3dcolourlbp'
        method_name = sprintf('HOG3DColourLBP_DVR_exact_1perSeq_trainN=%d', nptrain); % 'HOG3DColour_DVR_exact_1perSeq';  
end
fprintf('\n\n** %s, %s **\n\n', method_name, dataset_name);

%% Use fixed split for training and testing
splitfile = [Dataset_path, dataset_name, '/cv_split.mat']; %[Dataset_path, dataset_name, 'cv_split.mat']; %[datapath, 'cv_split.mat'];
if exist(splitfile, 'file')
    vars = load(splitfile);
    ls_set = vars.ls_set;
else
    ls_set = zeros(nfold, nperson);
    for foldidx = 1 : nfold
        ls_set(foldidx, :) = randperm(nperson);
    end
    save(splitfile, 'ls_set');
end

%% N fold
sim = cell(1, nfold);
er_avg = 0;
rates_avg = 0;
nauc_avg = 0;
parfor foldidx = 1 : nfold
% for foldidx = 1 : nfold
    
    sim{foldidx} = zeros(2*nperson, 2*nperson);
    
    %% split data into training set and testing set, and create bags for training
    %ls = randperm(nperson);
    ls = ls_set(foldidx, :);
    nptest = round(test_ratio*nperson);
    %nptrain = round(train_ratio*nperson);
    disp(['nptest = ', num2str(nptest), ', nptrain = ', num2str(nptrain)]);
    pidset_test = pidset(ls(1:nptest))';
    pidset_train = setdiff(pidset, pidset_test)';
    pidset_train = pidset_train(1:nptrain);
    % convert to row vector, required when used as index
    if(size(pidset_train, 1) > 1)
        pidset_train = pidset_train'; 
    end
    
    sel = [];
    for pid = pidset_train
        sel = [sel; find(X1(:,1) == pid)];
    end
    Xtr1 = X1(sel,:);
    sel = [];
    for pid = pidset_train
        sel = [sel; find(X2(:,1) == pid)];
    end
    Xtr2 = X2(sel,:);
    
    disp('creating boxes...')
    
    boxes = cell(numel(pidset_train), 2);
    
    for pid = pidset_train % for each person in cam1
        sampleSet = find(Xtr1(:,1) == pid)';
        boxidx = find(pid == pidset_train);
        
        bagplus = [];
        for i = sampleSet
            x1 = Xtr1(i, 4:end);
            sampleSet2 = find(Xtr2(:,1) == pid)';
            for j = sampleSet2
                x2 = Xtr2(j, 4:end);
                bagplus = [bagplus; abs(x1-x2)];
            end
        end
        
        bagminus = [];
        for i = sampleSet
            x1 = Xtr1(i, 4:end);
            sampleSet2 = setdiff(1:size(Xtr2,1), find(Xtr2(:,1) == pid));
            for j = sampleSet2
                if rand(rs{foldidx}, 1, 1) <= dnr
                    x2 = Xtr2(j, 4:end);
                    bagminus = [bagminus; abs(x1-x2)];
                end
            end
        end
        
        boxes{boxidx, 1} = bagplus;
        boxes{boxidx, 2} = bagminus;
    end
    
    nbox = size(boxes, 1);
    instplus = 0;
    instminus = 0;
    for boxidx = 1 : nbox
        instplus = instplus + size(boxes{boxidx, 1}, 1);
        instminus = instminus + size(boxes{boxidx, 2}, 1);
    end
    instplus = instplus / nbox;
    instminus = instminus / nbox;
    disp(['average number of instances in bag+ is ', num2str(instplus)]);
    disp(['average number of instances in bag- is ', num2str(instminus)]);
    
    %% Primal MIRankSVM
    [w, v, avgtime_rank, avgtime_sel] = primal_miranksvm_exact(boxes, penalty, maxiter, dw);
    disp('using primal_miranksvm_exact_speedup');
    
    disp(['average time for one ranking step is ', num2str(avgtime_rank/60), ' min']);
    disp(['average time for one selecting step is ', num2str(avgtime_sel/60), ' min']);
    
    %% Evalutation
    Sp = [];
    
    nptest = numel(pidset_test);
    ranks = zeros(1, nptest);
    for pid = pidset_test
        
        %@
        pidx = find(pid == pidset);
        idx_probe = (pidx-1)*2 + 1;
        Sp = [Sp, idx_probe];
        
        Xpid1 = X1(X1(:,1) == pid, 4:end);
        score = [];
        scoreplus = 0;
        for pid2 = pidset_test
            Xpid2 = X2(X2(:,1) == pid2, 4:end);
            maxs = -Inf;
            for i = 1 : size(Xpid1, 1)
                x1 = Xpid1(i,:);
                for j = 1 : size(Xpid2, 1)
                    x2 = Xpid2(j,:);
                    s = abs(x1-x2) * w;
                    if s >= maxs
                        maxs = s;
                    end
                end
            end
            score = [score, maxs];
            if pid == pid2
                scoreplus = maxs;
            end
            
            % similarity matrix
            pidx = find(pid == pidset);
            idx_probe = (pidx-1)*2 + 1;
            pidx2 = find(pid2 == pidset);
            idx_gallery = pidx2*2;
            
            sim{foldidx}(idx_gallery, idx_probe) = maxs;
            
        end
        rank = find(sort(score, 'descend') == scoreplus);
        ranks(pid == pidset_test) = rank(1);
    end
    rates = zeros(1, nptest); % match rates for each rank thresh
    for rank = 1 : nptest
        rates(rank) = 100 * sum(ranks <= rank) / nptest;
    end
    nauc = sum(rates/100) / nptest;
    er = mean(ranks);
    
    rates_avg = rates_avg + rates;
    er_avg = er_avg + er;
    nauc_avg = nauc_avg + nauc;
end

%%
result_path = ['../results/' dataset_name '/MIRank/'];
if(~exist(result_path, 'dir'))
    mkdir(result_path); 
end

% simlarity matrix
save([result_path, 'sim_' method_name], 'sim');

nptest = round(test_ratio*nperson);
rates = rates_avg / nfold;
er = er_avg / nfold;
nauc = nauc_avg / nfold;

feat_type
train_ratio
test_ratio
dnr
penalty
maxiter
dw

fprintf('\n\nFinal averaged results:\n\n');
for rank = rank_of_interest
    disp(['rank ', num2str(rank), ' : ', num2str(rates(rank)), '%']);
end

figure;
plot(1:nptest, rates, '-rs', 'linewidth', 2);
axis([1, nptest, 0, 100]);
xlabel('rank');
ylabel('match rate (%)');

%%
stop_t = clock;
timecost = etime(stop_t, start_t);
disp(['Time cost = ', num2str(timecost/60), ' mins']);


%%
save([result_path 'rates_' method_name '.mat'], 'rates', 'nauc', 'er', 'penalty', 'nptest', 'nfold', 'nperson', 'test_ratio', 'timecost');
disp([result_path 'rates_' method_name '.mat']);
fprintf('\n%s: DONE on %s (kept_train_ratio = %.3f)\n\n', method_name, dataset_name, kept_train_ratio);

