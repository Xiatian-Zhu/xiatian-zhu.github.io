% testbench_cross_dataset_evaluation
close all force
clear all
clc

start_t = clock;

%%
train_dataset = '../dataset/iLIDS_mirank/';
test_dataset = '../dataset/PRID_mirank/';

% train_dataset = '../dataset/PRID_mirank/';
% test_dataset = '../dataset/iLIDS_mirank/';

datapath = '../data1/';

% train_ratio of training data are used; no randomness
train_ratio = 0.5;
% downsample ratio for bag-
dnr = 0.25

% test_ratio of testing data are used in each cv
test_ratio = 0.5;

penalty_set = [1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9];

maxiter = 5;
dv = 1e-8;

rank_of_interest = [1 5 10 20 50];

cpuCoreNum = 3;

%%
if matlabpool('size') ~= cpuCoreNum && cpuCoreNum > 1
    matlabpool close force
    matlabpool('open', 'local', cpuCoreNum);
end

%% load training data
% data from cam 1
vars = load([train_dataset, 'X1.mat']);
% [person, cam, vid, feat]
X1 = vars.X;
% data from cam2
vars = load([train_dataset, 'X2.mat']);
% [person, cam, vid, feat]
X2 = vars.X;

disp(['feature dim = ', num2str(size(X1,2)-3)])

pidset_train_total = unique(X1(:,1))';
nperson_train_total = numel(pidset_train_total)

%% create training boxes
pidset_train = pidset_train_total(1 : round(1/train_ratio) : end);
disp(['number of training persons = ', num2str(numel(pidset_train))])

sel = [];
for pid = pidset_train
    sel = [sel; find(X1(:,1) == pid)];
end
Xtr1 = X1(sel,:);
sel = [];
for pid = pidset_train
    sel = [sel; find(X2(:,1) == pid)];
end
Xtr2 = X2(sel,:);

disp('creating boxes...')

boxes = cell(numel(pidset_train), 2);

for pid = pidset_train % for each person in cam1
    sampleSet = find(Xtr1(:,1) == pid)';
    boxidx = find(pid == pidset_train);
    
    bagplus = [];
    for i = sampleSet
        x1 = Xtr1(i, 4:end);
        sampleSet2 = find(Xtr2(:,1) == pid)';
        for j = sampleSet2
            x2 = Xtr2(j, 4:end);
            bagplus = [bagplus; abs(x1-x2)];
        end
    end
    
    bagminus = [];
    for i = sampleSet
        x1 = Xtr1(i, 4:end);
        sampleSet2 = setdiff(1:size(Xtr2,1), find(Xtr2(:,1) == pid));
        for j = sampleSet2
            if rand(1,1) <= dnr
                x2 = Xtr2(j, 4:end);
                bagminus = [bagminus; abs(x1-x2)];
            end
        end
    end
    
    boxes{boxidx, 1} = bagplus;
    boxes{boxidx, 2} = bagminus;
end

nbox = size(boxes, 1);
instplus = 0;
instminus = 0;
for boxidx = 1 : nbox
    instplus = instplus + size(boxes{boxidx, 1}, 1);
    instminus = instminus + size(boxes{boxidx, 2}, 1);
end
instplus = instplus / nbox;
instminus = instminus / nbox;
disp(['average number of instances in bag+ is ', num2str(instplus)])
disp(['average number of instances in bag- is ', num2str(instminus)])

%% loading testing data
% data from cam 1
vars = load([test_dataset, 'X1.mat']);
% [person, cam, vid, feat]
X1 = vars.X;
% data from cam2
vars = load([test_dataset, 'X2.mat']);
% [person, cam, vid, feat]
X2 = vars.X;

disp(['feature dim = ', num2str(size(X1,2)-3)])

pidset_test_total = unique(X1(:,1))';
nperson_test_total = numel(pidset_test_total)
nptest = round(test_ratio*nperson_test_total)

%% load testing split
vars = load([test_dataset, 'cv_split.mat']);
ls_set = vars.ls_set;
nfold = size(ls_set, 1)

%%
er_penalties = zeros(numel(penalty_set), 1);
rates_penalties = zeros(numel(penalty_set), nptest);
nauc_penalties = zeros(numel(penalty_set), 1);

for penalty = penalty_set
    
    %% Primal MIRankSVM
    [w, v] = primal_miranksvm(boxes, penalty, maxiter, dv);
    
    save([datapath, 'w', num2str(find(penalty == penalty_set)), '.mat'], 'w')
    
    %% Evaluation
    er_avg = 0;
    rates_avg = 0;
    nauc_avg = 0;
    parfor foldidx = 1 : nfold
        ls = ls_set(foldidx, :);
        nptest = round(test_ratio*nperson_test_total);
        
        disp(['fold idx = ', num2str(foldidx), ', nptest = ', num2str(nptest)])
        
        pidset_test = pidset_test_total(ls(1:nptest));
        
        nptest = numel(pidset_test);
        
        ranks = zeros(1, nptest);
        
        for pid = pidset_test
            Xpid1 = X1(X1(:,1) == pid, 4:end);
            score = [];
            scoreplus = 0;
            for pid2 = pidset_test
                Xpid2 = X2(X2(:,1) == pid2, 4:end);
                maxs = -Inf;
                for i = 1 : size(Xpid1, 1)
                    x1 = Xpid1(i,:);
                    for j = 1 : size(Xpid2, 1)
                        x2 = Xpid2(j,:);
                        s = abs(x1-x2) * w;
                        if s >= maxs
                            maxs = s;
                        end
                    end
                end
                score = [score, maxs];
                if pid == pid2
                    scoreplus = maxs;
                end
            end
            rank = find(sort(score, 'descend') == scoreplus);
            ranks(pid == pidset_test) = rank(1);
        end
        rates = zeros(1, nptest); % match rates for each rank thresh
        for rank = 1 : nptest
            rates(rank) = 100 * sum(ranks <= rank) / nptest;
        end
        nauc = sum(rates/100) / nptest;
        er = mean(ranks);
        
        rates_avg = rates_avg + rates;
        er_avg = er_avg + er;
        nauc_avg = nauc_avg + nauc;
    end
    
    nptest = round(test_ratio*nperson_test_total)
    rates_avg = rates_avg / nfold;
    er_avg = er_avg / nfold;
    nauc_avg = nauc_avg / nfold;
    
    rates = rates_avg;
    er = er_avg;
    nauc = nauc_avg;
    
    save([datapath, 'rates.mat'], 'rates')
    
    disp('----------------')
    % disp(['ER = ', num2str(er)])
    disp(['nAUC = ', num2str(nauc)])
    for rank = rank_of_interest
        disp(['rank ', num2str(rank), ' : ', num2str(rates(rank)), '%'])
    end
    
%     figure
%     plot(1:nptest, rates, '-rs', 'linewidth', 2)
%     axis([1, nptest, 0, 100])
%     xlabel('rank')
%     ylabel('match rate (%)')
    
    er_penalties(penalty == penalty_set) = er_avg;
    rates_penalties(penalty == penalty_set, :) = rates_avg;
    nauc_penalties(penalty == penalty_set, :) = nauc_avg;
end

disp('----------------')
for i = 1 : numel(penalty_set)
    er = er_penalties(i);
    rates = rates_penalties(i, :);
    nauc = nauc_penalties(i);
    disp('----------------')
    disp(['penalty = ', num2str(penalty_set(i))])
%     disp(['ER = ', num2str(er)])
    disp(['nAUC = ', num2str(nauc)])
    for rank = rank_of_interest
        disp(['rank ', num2str(rank), ' : ', num2str(rates(rank)), '%'])
    end
end

%%
stop_t = clock;
timecost = etime(stop_t, start_t);
disp(['Time cost = ', num2str(timecost/60), ' mins'])
