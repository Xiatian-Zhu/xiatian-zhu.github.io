
function search_CMC()

%% Search Salience+DVR
% prid:  41.7 64.5 77.5 88.8  
% scores = [41.7 64.5 77.5 88.8]; % <238>
% ilids: 30.9 54.4 65.1 77.1
% scores = [30.9 54.4 65.1 77.1]; % <243>


%% Search MS-SDALF+DVR
% prid:  31.6 58.0 70.3 85.3
% scores = [31.6 57.9 70.3 85.3]; % <237>
% ilids: 26.7 49.3 61.0 71.6 
% scores = [26.7 49.3 61.0 71.6]; % <242>


%% Search MS-Colour&LBP+DVR
% prid:  37.6 63.9 75.3 89.4
% scores = [37.6 63.9 75.3 89.4]; % <236>
% ilids: 34.5 56.7 67.5 77.5
scores = [34.5 56.7 67.5 77.5]; % <241>


folders = dir('./');
folders(1:2) = [];
for i = 1 : length(folders)
    cur_folder = folders(i);
    if cur_folder.isdir == 1
        rates_files = dir([cur_folder.name '/*.mat']);
        for j = 1 : length(rates_files)
            load([cur_folder.name '/' rates_files(j).name]);
            
            
            if(exist('rates', 'var'))
                
                if(length(rates) ~= 89 && length(rates) ~= 150 )
                    fprintf('oops'); 
                end
                try
                    
                if(floor(rates(1)) == floor(scores(1)) && ...
                    floor(rates(5)) == floor(scores(2)) && ...
                    floor(rates(10)) == floor(scores(3)) && ...
                    floor(rates(20)) == floor(scores(4)))
           
                    fprintf('%s, %s \n', cur_folder.name, rates_files(j).name);
                    return;
                end
                
                catch me
                    fprintf(me.message);  
                
                end
            end
        end
    end
end
    
end

