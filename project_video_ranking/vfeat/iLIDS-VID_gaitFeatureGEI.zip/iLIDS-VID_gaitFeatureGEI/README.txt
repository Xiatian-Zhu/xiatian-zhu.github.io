Gait features Gait Energy Image (GEI) extracted from the person image sequences of the iLIDS-VID dataset [1]. Each mat file corresponding to the feature vector of an image sequence. 


Reference:
[1] T. Wang, S. Gong, X. Zhu and S. Wang. Person Re-Identification by Video Ranking. In Proc. European Conference on Computer Vision, Zurich, Switzerland, September 2014.


Contact:
Taiqing Wang (taiqing.wang@foxmail.com)
Xiatian Zhu (Eddy.zhuxt@gmail.com)

2015 October 23