The CMC scores by our DVR model and baseline methods and fused ones on the iLIDS-VID and PRID2011 datasets. 
Each dataset has one separate directory. 
In each, the .mat files are named by the corresponding single or fused method name. 
Fused method name is in format of ''xxx_plus_DVR''
See Table 1~3 of the below paper for reference.



Reference:
Person Re-Identification by Video Ranking. 
T. Wang, S. Gong, X. Zhu and S. Wang.	
In Proc. European Conference on Computer Vision (ECCV), Zurich, Switzerland, September 2014. 
