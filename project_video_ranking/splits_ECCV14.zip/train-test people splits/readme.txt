

One could find a 10 x #persons matrix inside each matlab data file. For each of the 10 trials, we used the first 50% persons for testing and the remaining for training in our work (below). 

If you use our dataset in your work, please appropriately cite our ECCV 2014 paper:

Person Re-Identification by Video Ranking. T. Wang, S. Gong, X. Zhu and S. Wang.	
In Proc. European Conference on Computer Vision (ECCV), Zurich, Switzerland, September 2014. 